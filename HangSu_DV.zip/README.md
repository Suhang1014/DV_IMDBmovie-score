# DataVisualization_cw_movie-score
## Topic: What kinds of movie are more likely to get high score?

**I used JQuery in this project, thus if you open the `html` file in the Data_Story_code directly, the charts may not shown and the browser may told you that it break the CORS policy.**

**You can open this project using an IDE and then preview it.**

**Or you can see the sample result at: https://Suhang1014.github.io/**
